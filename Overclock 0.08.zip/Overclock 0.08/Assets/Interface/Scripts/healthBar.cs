﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class healthBar : MonoBehaviour 
{
	public GameObject player;
	public Image HPFill;

	void Start () {
		
	}

	void Update () 
	{
		HPFill.fillAmount = player.GetComponent<player> ().PlayerStats.currentHealth / player.GetComponent<player>().PlayerStats.maxHealth;
	}
}
