﻿using UnityEngine;
using System.Collections;

public class gameMaster : MonoBehaviour {

	public static void killPlayer (player player){
		killPlayer (player);
}

}
