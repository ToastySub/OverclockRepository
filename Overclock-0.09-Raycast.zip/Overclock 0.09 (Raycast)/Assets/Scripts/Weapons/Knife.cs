﻿using UnityEngine;
using System.Collections;

public class Knife : Weapon {

	public Knife() : base("Knife", 5, 0) {
		
	}

	/*
	 * TODO:
	 *    - Make sure the player can swing only a certain amount of times per second
	 *    - Setup a small raycast to check for enemies close to the player (Make sure it can damage multiple at a time)
	 */
	public override void UseWeapon(){

	}
}