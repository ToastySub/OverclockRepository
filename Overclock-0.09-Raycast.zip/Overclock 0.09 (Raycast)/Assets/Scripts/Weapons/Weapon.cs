﻿using UnityEngine;
using System.Collections;

public abstract class Weapon : MonoBehaviour {

	private string name;
	private int damage;
	private int criticalChance;

	// TODO: Find out what to do with the critical chance attack.

	public Weapon(string name, int damage, int critical){
		this.name = name;
		this.damage = damage;
		this.criticalChance = critical;
	}

	string GetName(){
		return name;
	}

	void SetDamage(int damage){
		this.damage = damage;
	}

	int GetDamage(){
		return damage;
	}

	void SetCriticalChance(int critical){
		this.criticalChance = critical;
	}

	int GetCriticalChance(){
		return criticalChance;
	}

	abstract public void UseWeapon();
}