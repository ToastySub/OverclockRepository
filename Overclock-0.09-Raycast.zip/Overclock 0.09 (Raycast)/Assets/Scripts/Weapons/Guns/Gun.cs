﻿using UnityEngine;
using System.Collections;

public abstract class Gun : Weapon {


	// This class is a WIP

	string test;


	// This method will be called whenever a player shoots, but will check some certain things such as ammo to make sure the player can shoot. If he can, then call the shoot method
	// and let the other class handel the rest.
	public override void UseWeapon () {

	}

	public abstract void Shoot();
}