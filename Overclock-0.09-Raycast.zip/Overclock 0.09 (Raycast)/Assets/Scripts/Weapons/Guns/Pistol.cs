﻿using UnityEngine;
using System.Collections;

public class Pistol : Gun {

	public Pistol() : base("sD"){

	}
}