﻿using UnityEngine;
using System.Collections;

public abstract class Entity : MonoBehaviour {

	private float health;
	private float maxHealth;

	public Entity(){

	}

	public void SetHealth(float health){
		this.health = health;
	}

	public float GetHealth(){
		return health;
	}

	public float GetMaxHealth(){
		return maxHealth;
	}

	public void Die(){
	
	}
}