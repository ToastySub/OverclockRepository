﻿using UnityEngine;
using System.Collections;

public class Walking : MonoBehaviour {
	public float speed;
	public float jumpheight;
	float moveVelocity;
	bool grounded = true;
	public Animator animator;
	bool faceLeft;

	void start()
	{
		animator.GetComponent<Animator> ();
	}

	void Update () 
	{
		if (Input.GetKeyDown (KeyCode.Space) || Input.GetKeyDown (KeyCode.W)) 
		{
			if (grounded)
			{
				GetComponent<Rigidbody2D> ().velocity = new Vector2 (GetComponent<Rigidbody2D> ().velocity.x, jumpheight);
			}
		}
		if(Input.GetKey(KeyCode.A))
		{
			GetComponent<Rigidbody2D> ().velocity = new Vector2 (-speed, GetComponent<Rigidbody2D> ().velocity.y);
			animator.SetBool ("isWalking", true);
			faceLeft = true;
		}
		if(Input.GetKey(KeyCode.D))
		{
			GetComponent<Rigidbody2D> ().velocity = new Vector2 (speed, GetComponent<Rigidbody2D> ().velocity.y);
			animator.SetBool("isWalking", true);
			faceLeft = false;
		}
		if (!Input.GetKey (KeyCode.A) && !Input.GetKey (KeyCode.D)) 
		{
			animator.SetBool ("isWalking", false);

		}
		if (faceLeft)
			transform.localScale = new Vector3 (-1, 1, 1);
		else
			transform.localScale = new Vector3(1, 1, 1);
	}
}
