﻿using UnityEngine;
using System.Collections;

public class bullet : MonoBehaviour {
	public GameObject player;

	void OnCollisionEnter2D(Collision2D col)
	{
		if (col.gameObject.tag == "Player")
			player.GetComponent<player> ().DamagePlayer (20);
			Destroy (gameObject);
	}
}
