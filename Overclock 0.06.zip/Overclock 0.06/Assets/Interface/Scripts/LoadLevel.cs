﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;		
public class LoadLevel : MonoBehaviour {
	
	void Awake()
	{
		this.enabled = false;
	}
	void OnEnable() 
	{
		SceneManager.LoadScene("Overclock 0.04");
	}
}